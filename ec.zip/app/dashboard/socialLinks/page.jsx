import React from 'react'
import SocialLinksForm from './components/SocialLinksForm'

export default function page() {
  return (
    <SocialLinksForm />
  )
}
