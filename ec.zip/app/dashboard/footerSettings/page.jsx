import React from 'react'
import FooterSettingsForm from './components/FooterSettingsForm'

export default function page() {
  return (
      <FooterSettingsForm />
  )
}
