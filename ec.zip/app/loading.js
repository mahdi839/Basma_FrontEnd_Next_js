
import Loader from "./components/loader/pageLoader";

// app/loading.js
export default function Loading() {
  return (
    <Loader />
  )
}